#include <iostream>
using namespace std;

int a,b;

int main() 
{
	cout<<"Digite um numero: ";
	cin>>a;
	
	b=a%2;
	
	if (b==0)
	{cout<<"O numero e par";
	}
	else
	{cout<<"O numero e impar";
	}
	
	
	
	return 0;
}
